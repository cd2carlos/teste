# Caso de referência: DataUser - captura pública de 01/11/2026

**Escopo da evidência:** PDF de 3 páginas com captura longa de interface pública em localhost; NÃO contém código-fonte nem telas internas administrativas. Não assumir a existência ou funcionamento de rotas específicas além das visíveis.

## Inventário preliminar com base apenas na captura
- PUB-001: navegação superior com Início, A DataUser, Soluções Públicas, Sistemas Web, Emendas e Consultoria, Área do Cliente, Contato e Administração
- PUB-002: banner/hero com imagem fluvial, título, CTA e possíveis indicadores do carrossel
- PUB-003: apresentação DataUser / sistemas web para serviço público e benefícios
- PUB-004: consultoria, treinamento e emendas parlamentares
- PUB-005: sistemas web responsivos, cards e filtros/categorias de catálogo
- PUB-006: catálogo geral anunciado com 18 sistemas
- PUB-007: seção A DataUser e acordeão/serviços
- PUB-008: Área do Cliente com serviços, contatos e link do painel administrativo
- PUB-009: formulário de contato e rodapé
- ADMIN-?: acesso administrativo indicado na interface, mas páginas internas NÃO examinadas

## Achados visuais para verificar no repositório e navegador
- Legibilidade e contraste do texto do hero sobre imagem
- Densidade dos cards extensos de sistemas versus catálogo compacto
- Relação entre menu público, âncoras e efetivas rotas
- Experiência mobile do catálogo, carrossel e formulário
- Hierarquia dos CTAs de demonstração, apresentação, consultoria e administração
- Verificar antes de alterar qualquer comportamento real

**Regra:** Esta lista é ponto de partida, não inventário verificado nem validação de funcionamento. Descobrir tudo pelo código e interface em execução.
