# Modelos obrigatórios de inventário, acompanhamento e relatório

## 01-inventario.md
Cabeçalho: projeto, data, escopo, fonte da descoberta (rotas/menu/código/interface), limitações de acesso.

| ID | Módulo | Menu > submenu | Tela/rota | Arquivo principal | Componentes/modais | Acesso/inspeção | Observações |
|---|---|---|---|---|---|---|---|
| ADM-001 | Exemplo (substituir) | ... | ... | ... | ... | Acessível / Inacessível / Não verificada | ... |

Totais: telas identificadas = N; acessíveis = N; inacessíveis = N; não verificadas = N. Os totais devem coincidir com as linhas reais.

## 02-diagnostico.md

| ID | Problema observado | Evidência (arquivo/tela/captura) | Impacto | Severidade (P0-P3) | Nota 0–3 / eixo | Correção recomendada |
|---|---|---|---|---|---|---|

Não atribuir notas a telas não inspecionadas; marcar `Não avaliada`.

## 03-matriz-acompanhamento.md

| ID | Módulo / tela / rota | Achado | Prioridade | Mudança planejada | Arquivos alterados | Execução | Teste visual | Teste funcional | Evidência | Pendência |
|---|---|---|---|---|---|---|---|---|---|---|

Execução: Não iniciada / Em andamento / Implementada sem validação / Validada / Bloqueada / Fora do escopo.
Testes: Aprovado / Falhou / Não executado / Bloqueado. Para tela sem edição por já estar adequada, registrar `Sem alteração necessária` com inspeção e validação documentadas.

## 04-relatorio-final.md

### 1. Escopo e cobertura
Total de telas levantadas e quantas estão validadas, sem alteração necessária, pendentes, bloqueadas, inacessíveis e fora do escopo. Não contar a mesma tela duas vezes. Declarar limitações.

### 2. Modificações realizadas
Resumo por módulo, por ID e por arquivo, destacando mudanças globais que afetam várias telas.

### 3. Verificações reais
Comando/teste, ambiente, resultado, evidência e telas cobertas. Não citar testes não executados como aprovados.

### 4. Problemas e pendências
| ID | Pendência | Motivo | Próximo passo | Status |
|---|---|---|---|---|

### 5. Resultado e ponto de retomada
Status: `Concluída integralmente` ou `Conclusão parcial`, com critério objetivo; lista de itens seguintes caso parcial.

## Mensagem final ao solicitante
"Inventariei X telas, corrigi Y, validei Z e deixei W pendentes/bloqueadas. Principais mudanças: (...). Testes executados: (...). Não verificado: (...). Relatório: `admin-design-audit/04-relatorio-final.md`. Status: (...)."

Usar apenas quantidades confirmadas. Em análise sem implementação, declarar isso explicitamente.
