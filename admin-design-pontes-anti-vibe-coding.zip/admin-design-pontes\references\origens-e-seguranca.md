# Origens pesquisadas e segurança - 01/11/2026

Fontes consultivas, não dependências executadas nem arquivos copiados na íntegra:
- UI UX Pro Max: https://github.com/nextlevelbuilder/ui-ux-pro-max-skill/blob/main/.claude/skills/ui-ux-pro-max/SKILL.md
- Frontend Design / Anthropic: https://github.com/anthropics/skills/blob/main/skills/frontend-design/SKILL.md
- Impeccable: https://github.com/pbakaus/impeccable/blob/main/plugin/skills/impeccable/SKILL.md
- Vercel Agent Skills / Web Design Guidelines: https://github.com/vercel-labs/agent-skills/tree/main/skills/web-design-guidelines
- Google Search Central (SEO): https://developers.google.com/search/docs/fundamentals/seo-starter-guide
- Google Search Central (Core Web Vitals): https://developers.google.com/search/docs/appearance/core-web-vitals
- W3C WCAG 2.2: https://www.w3.org/TR/WCAG22/

Critérios: nenhuma execução automática de scripts de terceiros; nenhum download de dependências; nenhuma alteração de backend, login ou permissões. Estrelas do GitHub não constituem auditoria de segurança. Qualquer ferramenta futura exige revisão de scripts, licenças, versões e permissões antes de uso.
