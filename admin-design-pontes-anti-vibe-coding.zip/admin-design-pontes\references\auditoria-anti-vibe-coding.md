# Checklist Anti-Vibe Coding e Padrões Reais das Skills Campeãs (`frontend-design`, `hallmark`, `impeccable`, `taste-skill`)

Este documento consolida as regras exatas de **Floor e Anti-Slop** extraídas diretamente das skills originais instaladas (`anthropics/skills/frontend-design`, `Nutlope/hallmark`, `pbakaus/impeccable` e `Leonxlnx/taste-skill`) para impedir que sites institucionais, B2B e GovTech fiquem com aparência genérica, amadora ou gerada por IA.

---

## 1. Os 7 Sinais Clássicos de IA que são Estritamente Proibidos

Extraídos literalmente de `frontend-design` (L38–44) e `hallmark` (L18–36):

1. **Proibido "Template Chrome" e Códigos Falsos em Monospace (`frontend-design` L43 & `hallmark` L29-30):**
   - **Proibido** colocar um *eyebrow* em CAIXA ALTA espaçada (`text-xs uppercase tracking-wider`) acima de cada título (`h1`, `h2`, `h3`).
   - **Proibido** criar rótulos e metadados unidos por ponto médio (`A · B · C`), travessão espaçado (`PALAVRA — fragmento`) ou barras (`01 / 04`).
   - **Proibido** inventar códigos técnicos em fonte monoespaçada para itens de marketing ou catálogo (`SYS-001`, `MOD-01`, `ETAPA 01`, `01 · OBJETIVO`) quando não forem identificadores operacionais reais de um banco de dados administrativo.
   - **Proibido** colar setas Unicode (`→` ou `↗`) no final do texto de botões e links.

2. **Proibido Numeração Falsa (`01`, `02`, `03`) em Itens Não-Sequenciais (`hallmark` L31):**
   - Só numere itens quando a própria ordem for o assunto (ex.: passos cronológicos reais). Nunca numere cartões de benefícios, modalidades ou perguntas frequentes com `01`, `02`, `03`.

3. **Proibido "Jornal / Broadsheet" Falso e Grades de Caixas Coladas (`frontend-design` L41):**
   - **Proibido** transformar páginas institucionais em grades densas de células `gap-px` com zero border-radius e textos técnicos simulando terminal ou jornal.

4. **Proibido Cards e Modais com "Shape Padrão de IA" (`impeccable` & `hallmark` L26):**
   - **Proibido** o cartão padrão com borda superior colorida (`border-t-4`), quadradinho de ícone no topo (*icon tile*), badge no canto e botão embaixo.
   - **Proibido** abrir os detalhes de um produto/sistema em um **modal popup genérico** com cabeçalho azul escuro e 4 caixinhas cinzas numeradas (`01 · OBJETIVO`, `02 · PÚBLICO`, etc.). Cada solução/produto relevante deve ter **sua própria página dedicada (`/solucoes/:slug`)** com leitura limpa e editorial.

5. **Proibido Poluição na Página Inicial — Regra de ~80 Palavras por Dobra (`hallmark` L32-34 & `taste-skill`):**
   - **Uma ideia por tela**, com no máximo 2 regiões por seção.
   - Quando o Hero usar **fotografia panorâmica de paisagem/arquitetura (como fotos de Manaus/AM)**, ela deve ocupar toda a largura como plano de fundo cinematográfico (*full-bleed*) com o **texto principal posicionado pela frente da imagem** sobre um *scrim* escuro natural para leitura perfeita — nunca espremida como uma figurinha pequena na lateral.
   - **Proibido** colocar barras de especificações (`01 · CONTRATAÇÃO`, `02 · ARQUITETURA`) dentro do Hero ou empilhar dezenas de cartões na página inicial.

6. **Proibido "Tudo na Mesma Página" ou Menus que Voltam para a Home (`taste-skill` & `admin-design-pontes`):**
   - Cada item do menu principal deve ser um **componente de página separado com rota própria** (`/`, `/solucoes`, `/solucoes/:slug`, `/consultoria`, `/empresa`, `/atendimento`), nunca uma página comprida com âncoras (`#`) nem um arquivo monolítico confuso.

7. **Proibido Contraste Agressivo de Blocos Azul-Marinho Escuro + Cinza Frio em Tudo:**
   - Em sites institucionais diurnos (*daylight-first*), prefira fundo claro acolhedor e limpo (`#FAF9F5` ou `#FFFFFF`), texto em tinta escura legível (`#111827` / `#1E293B`), divisórias sutis e cor de destaque institucional usada com parcimônia apenas na ação principal e no estado ativo do menu.

---

## 2. Arquitetura Recomendada para Sites Institucionais e Catálogos B2B/GovTech

1. **Navegação Multi-Página Real (1 Rota = 1 Componente de Página):**
   - `/` (`HomePage`): Recepção limpa e despoluída. Hero direto + índice editorial enxuto das soluções em destaque (em formato de lista editorial limpa, sem grade de caixas).
   - `/solucoes` (`CatalogPage`): Diretório com busca, filtro simples em sentence case e listagem clara onde clicar em qualquer sistema abre sua página própria (`/solucoes/:slug`).
   - `/solucoes/:slug` (`SystemDetailPage`): Página própria de cada sistema (substituindo modais), com visão geral, a quem atende, principais entregas e solicitação direta de apresentação.
   - `/consultoria` (`ConsultingPage`): Página própria para serviços de consultoria, análise de viabilidade técnica em emendas parlamentares e capacitação.
   - `/empresa` (`CompanyPage`): Página própria sobre a instituição, formas de contratação (venda do código-fonte, cessão de uso, desenvolvimento sob medida) e dúvidas frequentes.
   - `/atendimento` (`ContactPage`): Página própria de contato e solicitação de demonstração.

2. **Tipografia Humana (Sentence Case Sempre):**
   - Rótulos de navegação, categorias, cabeçalhos de tabela e botões sempre em **sentence case** (primeira letra maiúscula, demais minúsculas), na mesma família tipográfica do corpo, sem `uppercase` e sem `font-mono` decorativo.

---

## 3. Verificação por Tela (Checklist de Aprovação)

Para cada rota do projeto, validar e registrar `conforme` ou `corrigido`:
- [ ] A rota possui componente e URL próprios (não rola a página inicial nem volta para a Home)?
- [ ] Há zero códigos falsos (`SYS-001`, `MOD-01`, `ETAPA 01`, `01 · ...`)?
- [ ] Há zero *eyebrows* em CAIXA ALTA espaçada acima dos títulos?
- [ ] Há zero pontos médios (`·`) ou travessões (`—`) artificiais em subtítulos?
- [ ] A página inicial (`/`) é enxuta, com respiro generoso e sem grade poluída de cartões?
- [ ] Clicar em um sistema abre uma página dedicada (`/solucoes/:slug`) em vez de um modal com caixinhas padrão?
- [ ] Contraste WCAG 2.2 AA, navegação por teclado e responsividade (1440px, 768px, 390px) preservados?
