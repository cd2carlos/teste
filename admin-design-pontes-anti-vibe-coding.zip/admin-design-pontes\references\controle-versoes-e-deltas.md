# Controle de versão, comparação e novidades por execução

## Objetivo
A cada invocação, ser objetivo: identificar novidades da skill, alterações do projeto e pendências anteriores, evitando repetir diagnósticos sem necessidade.

## Fontes de verdade
- `VERSION.json` + `CHANGELOG.md` da skill: versão e mudanças normativas.
- `admin-design-audit/skill-state.json` do projeto: versão **efetivamente aplicada**, hashes, escopo e cobertura; nunca é gravado na pasta global da skill.
- `admin-design-audit/01-inventario.md` e `03-matriz-acompanhamento.md`: inventário e itens herdados.
- Git (`git diff`, estado de trabalho) quando disponível e seguro: alterações desde commit base registrado. Não usar comandos destrutivos.

## Algoritmo sugerido
1. Ler versão instalada e versão aplicada ao projeto.
2. Comparar histórico e listar apenas IDs novos; em downgrade ou histórico inconsistente avisar.
3. Reexaminar árvore de rotas, menus e componentes; comparar conjunto de IDs e caminhos com baseline.
4. Detectar telas novas, removidas, renomeadas, rotas alteradas, componentes compartilhados modificados; rotas dinâmicas exigem análise explícita.
5. Priorizar deltas, pendências e regressões; preservar cobertura das demais rotas por amostragem justificada, sem alegar validação total.
6. Exibir as 4 opções de execução e o checklist específico do escopo.
7. Registrar execução real e evidências. Se incompleta, status = parcial, com escopo e pendências.
8. Atualizar snapshot no projeto somente após executar o que está descrito.

## Exemplo de schema do estado (NÃO é um resultado real)
```json
{
  "schema_version": 1,
  "skill": "admin-design-pontes",
  "last_applied_skill_version": "5.0.0",
  "skill_manifest_sha256": "<hash realmente calculado>",
  "executed_at": "<ISO 8601 realmente obtido>",
  "scope": "completo",
  "mode": "auditoria_e_implementacao",
  "status": "parcial",
  "inventory_path": "admin-design-audit/01-inventario.md",
  "report_path": "admin-design-audit/04-relatorio-final.md",
  "applied_change_ids": ["V5-01"],
  "validated_screen_ids": [],
  "pending_screen_ids": [],
  "route_snapshot": [],
  "source_revision": "<commit real ou null>"
}
```

É proibido manter placeholders no estado real, fingir que a instalação foi aplicada ou concluir automaticamente quando há pendências.
