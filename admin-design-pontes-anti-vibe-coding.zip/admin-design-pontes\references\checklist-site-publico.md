# Checklist especializado por ambiente - v3.0

## Classificação obrigatória
- [ ] Localizou entradas de rota, menus, layouts, autenticação e navegação entre público/cliente/admin
- [ ] Separou PUBLICO, CLIENTE, ADMIN, COMPARTILHADO, TECNICA, INDETERMINADO
- [ ] Identificou persona/objetivo sem inventar perfil; indicou inferências
- [ ] Encontrou páginas ocultas por navegação, rotas dinâmicas, erro, 404, login, loading, modais e estados

## Site público e comercial
- [ ] Proposta de valor clara e fundamentada; CTA primário/secundário; títulos específicos
- [ ] Menu público e navegação móvel; âncoras e links funcionais
- [ ] Hero legível com contraste e crop em desktop/mobile
- [ ] Serviços/produtos identificáveis, cards com altura e densidade adequadas
- [ ] Catálogo completo navegável e legível; filtros e agrupamentos úteis
- [ ] Formulário: labels, foco, estados, mensagens, privacidade, sem alterar envio
- [ ] Provas sociais verdadeiras; sem dados, depoimentos ou métricas inventadas
- [ ] Footer, contato e páginas legais visíveis e coerentes
- [ ] Semântica, headings, metadata, imagens, alt, performance e SEO básico

## Área do cliente
- [ ] Caminho de acesso, recuperação, navegação e saída observados na interface
- [ ] Solicitações, acompanhamento, feedback, erros e estados vazios
- [ ] Sem alteração indevida de permissões, autenticação ou dados

## Admin
- [ ] Menus/submenus, links, breadcrumbs, status selecionado
- [ ] Dashboard, unidades e períodos, tabelas e ações
- [ ] Filtros, CRUD visual, formulários, modais e estados; sem tocar regras funcionais
- [ ] Dados densos, responsividade e teclado

## Compartilhado e validação
- [ ] Tokens e componentes comuns; cada mudança ligada às telas afetadas
- [ ] Teclado, foco, contraste, labels, zoom/reflow, movimento reduzido (WCAG 2.2 AA como alvo)
- [ ] Responsividade: 390, 768, 1280 e 1440 px onde possível
- [ ] SEO e Core Web Vitals somente se realmente medidos (LCP, INP, CLS)
- [ ] Sem regressões de links, botões, formulários, estados e navegação
- [ ] Matriz atualizada, antes/depois, testes reais e pendências transparentes
