# AdminDesignPontes 4.0 - Menu e checklists apresentados ao usuário

Ao abrir a skill exibir menu 1/2/3/4 definido no `SKILL.md`. Após a escolha, apresentar o checklist COMPLETO adequado abaixo, antes de inventariar/editar. Os itens são **critérios de verificação** e não achados ou promessas de modificação. Após inspecionar o projeto, vincular cada critério às telas reais e atualizar a matriz.

## 1. Site público / institucional / comercial

- [ ] Identidade visual, coerência de marca, tokens, cores e tipografia
- [ ] Topo, logo, menus, submenus, navegação móvel e rodapé
- [ ] Página inicial, hero/banner, mensagens, contraste e chamadas para ação
- [ ] Páginas institucionais, sobre, serviços, público-alvo e credibilidade
- [ ] Produtos, sistemas, catálogo, categorias, cards, detalhes, busca/carrossel
- [ ] Área do cliente acessível a visitantes, entradas de login e jornadas de contato
- [ ] Formulários, validação visual, rótulos, feedback e privacidade na interface
- [ ] Botões, links, ícones, espaçamentos, alinhamentos e microtextos
- [ ] Estados loading/vazio/erro/sucesso/hover/foco e links quebrados
- [ ] Responsividade mobile, tablet, desktop e zoom/reflow
- [ ] Acessibilidade WCAG 2.2 AA como alvo, teclado, contraste, semântica e foco
- [ ] Performance observável (LCP/INP/CLS se houver ferramentas e dados)
- [ ] SEO técnico visual/semântico, títulos, headings, metadados e alt (quando em escopo)
- [ ] Evidências antes/depois, riscos e preservação dos fluxos originais

## 2. Painel administrativo / backoffice

- [ ] Inventário do shell, login, menus, submenus, rotas, perfis e breadcrumbs
- [ ] Dashboard: KPIs, filtros, visualizações, legenda, período e estados
- [ ] Telas de listagem, tabelas, grids, largura, densidade, ordenação e paginação (sem mudar regras)
- [ ] Filtros, pesquisa, seleção, limpar/aplicar, feedback e consistência
- [ ] Formulários: agrupamento, máscaras existentes, labels, erros, obrigatoriedade
- [ ] Fluxos CRUD visuais e confirmação de ações (sem mudar regra de negócio)
- [ ] Modais/drawers, abertura, fechamento, preservação de rascunho e foco
- [ ] Menus e navegação, estados ativos, menu colapsável e visibilidade
- [ ] Feedback: notificações, estados loading/vazio/erro/sucesso/sem permissão
- [ ] Tipografia, densidade, espaçamento, cores, ícones e design system
- [ ] Responsividade, tabelas extensas, overflow e áreas tocáveis
- [ ] Acessibilidade WCAG 2.2 AA como alvo, teclado, contraste e foco
- [ ] Consistência entre telas/estados e prevenção de regressões visuais
- [ ] Testes reais de renderização/build/lint e caminhos críticos quando disponíveis
- [ ] Evidências antes/depois, riscos e preservação de APIs/permissões/dados

## 3. Projeto completo

Mostrar **ambas as listas 1 e 2** (sem abreviar) mais:
- [ ] Descobrir e inventariar área do cliente, login e componentes compartilhados
- [ ] Separar `PUBLICO`, `CLIENTE`, `ADMIN`, `COMPARTILHADO`, `TECNICA`, `INDETERMINADO`
- [ ] Registrar dependências entre layouts, componentes, tokens e rotas
- [ ] Validar navegação e transições público > login > cliente/admin, quando autorizadas
- [ ] Registrar cobertura separada por área no relatório, sem confundir resultados

## 4. Somente diagnóstico

Mostrar checklist de 1/2/3 segundo escolha complementar. **Não editar** arquivos do produto; criar apenas artefatos de diagnóstico e auditoria quando permitido. Reportar as melhorias propostas e os testes não executados.

## Etapas sempre visíveis no início

1. Reconhecimento do repositório e delimitação de acesso
2. Inventário numerado de menus, rotas, páginas, componentes, modais e estados
3. Diagnóstico com evidências e prioridades
4. Design system e plano por tela
5. Implementação visual (exceto diagnóstico somente)
6. Testes, segunda revisão e validação por tela
7. Prestação de contas final com números exatos, arquivos, testes e pendências

## Estrutura do relatório de retorno na conversa

```text
AdminDesignPontes | Resultado final
Área escolhida: ...  | Modo: ...
Identificadas: N telas (público N / cliente N / admin N)
Inspecionadas: N | Alteradas: N | Validadas: N
Sem alterações necessárias: N | Bloqueadas: N | Pendentes: N
Mudanças concretas por módulo/tela (IDs): ...
Arquivos modificados: ...
Testes executados e resultados reais: ...
Não executado / não acessível: ...
Relatório: admin-design-audit/04-relatorio-final.md
Status: Concluída integralmente / Conclusão parcial
```

**Nunca inventar números e nunca marcar uma página como validada sem evidência.**
