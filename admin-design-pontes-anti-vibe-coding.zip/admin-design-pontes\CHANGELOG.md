# Histórico de versões - AdminDesignPontes

## 5.0.0 - 2026-11-02
**Novas regras:**
- V5-01: comparação automática entre versão instalada e última versão realmente aplicada ao projeto.
- V5-02: abertura objetiva com novidades da skill separadas de novidades do projeto.
- V5-03: baseline `admin-design-audit/skill-state.json`, persistido apenas após execução real.
- V5-04: inventário diferencial de rotas/telas/componentes e tratamento explícito de histórico ausente.
- V5-05: auditoria anti-vibe coding por tela, focada em identidade, densidade, hierarquia, CTAs e acabamento.
- V5-06: avaliação editorial para catálogos, cards, carrosséis e seções repetidas.
- V5-07: reauditoria obrigatória de mudanças compartilhadas e regressões.
- V5-08: prestação de contas do que foi novo, aplicado, verificado e pendente.

## 4.0.0 - versão anterior
- Menu guiado com quatro opções.
- Checklist antes da execução; inventário completo de público, cliente e administrativo.
- Diagnóstico, matriz de acompanhamento, implementação, validação e relatório final.

## 3.x - histórico resumido
- Identificação de ambientes públicos e administrativos e modelo inicial DataUser.

Nota: versões antigas são descritas de forma resumida porque não há registro granular auditável de cada mudança anterior.
