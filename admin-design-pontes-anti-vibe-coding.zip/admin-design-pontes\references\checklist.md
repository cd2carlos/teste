# Checklist por tela administrativa

- [ ] Reconhece contexto, usuário e tarefa principal
- [ ] Identidade visual distintiva, sem estética genérica de IA
- [ ] Título, hierarquia, navegação e ação principal claros
- [ ] Menu e item ativo visíveis e consistentes
- [ ] Espaçamento, alinhamento e densidade uniformes
- [ ] Tipografia, pesos e capitalização coerentes
- [ ] Paleta funcional, estados e contraste adequados
- [ ] Campos, selects e botões têm dimensões proporcionais
- [ ] Tabelas legíveis com números alinhados
- [ ] Filtros claros, com espaço e resultado previsível
- [ ] Modais coerentes com conteúdo e dispositivos
- [ ] Estados de vazio, erro, carregando, seleção e sucesso
- [ ] Foco visível e teclado operante
- [ ] Testado em 1440, 1280, 768 e 390 px
- [ ] Sem regressões de funcionalidades nem alterações de APIs
- [ ] Evidência de validação e pendências registradas

## Governança do trabalho completo
- [ ] Escopo e limitações declarados antes das mudanças
- [ ] Inventário inclui menus, submenus, rotas, páginas e modais
- [ ] Cada tela tem ID único e arquivo/rota identificados quando disponíveis
- [ ] Diagnóstico e evidência registrados por tela
- [ ] Matriz de execução atualizada durante cada alteração
- [ ] Arquivos e componentes alterados rastreados até as telas afetadas
- [ ] Segunda passagem visual e verificação de regressões realizadas ou explicitamente não realizadas
- [ ] Itens bloqueados/inacessíveis/não avaliados claramente separados
- [ ] Relatório final com totais conferidos, testes reais, pendências e ponto de retomada
- [ ] Status final não declara conclusão integral com telas pendentes
